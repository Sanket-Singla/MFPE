package com.pharmacy.cts.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.google.common.net.HttpHeaders;
import com.pharmacy.cts.config.AuthServiceProxi;
import com.pharmacy.cts.config.MedicineStockServiceProxi;
import com.pharmacy.cts.exception.InvalidTokenException;
import com.pharmacy.cts.model.MedicineDemand;
import com.pharmacy.cts.model.MedicineStock;
import com.pharmacy.cts.model.PharmacyMedicineSupply;
import com.pharmacy.cts.service.PharmacyService;

@SpringBootTest
@AutoConfigureMockMvc
class PharmacyControllerTest {

	@MockBean
	private MedicineStockServiceProxi medicineStockServiceProxi;

	@Autowired
	private PharmacyController pharmacyController;

	@MockBean
	private PharmacyService pharmacyService;

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private AuthServiceProxi authenticateProxi;

	@Test
	void contextLoads() throws Exception {
		assertThat(pharmacyController).isNotNull();

	}

	@Test
	void testControllerLogic() throws Exception {

		String token = "dummy";
		when(authenticateProxi.validate("Bearer " + token)).thenReturn(true);

		List<MedicineStock> medicines = new ArrayList<>();
		medicines.add(new MedicineStock(1, "Orthoherb", Arrays.asList("ch1", "ch2", "ch3"), "Orthopaedics",
				LocalDate.now(), 10));
		medicines.add(new MedicineStock(2, "Cholecalciferol", Arrays.asList("ch2", "ch3"), "Gynaecology",
				LocalDate.now(), 5));

		when(medicineStockServiceProxi.getMedicineStockInfo("Bearer " + token)).thenReturn(medicines);

		List<PharmacyMedicineSupply> pharmacistList = new ArrayList<PharmacyMedicineSupply>();
		pharmacistList.add(new PharmacyMedicineSupply("Phar1", "Orthoherb", 5));
		pharmacistList.add(new PharmacyMedicineSupply("Phar2", "Orthoherb", 5));
		pharmacistList.add(new PharmacyMedicineSupply("Phar1", "Cholecalciferol", 1));
		pharmacistList.add(new PharmacyMedicineSupply("Phar2", "Cholecalciferol", 1));

		List<MedicineDemand> medicineDemandList = new ArrayList<MedicineDemand>();

		medicineDemandList.add(new MedicineDemand("Orthoherb", 15));
		medicineDemandList.add(new MedicineDemand("Cholecalciferol", 2));
		when(pharmacyService.getPharmacyCount(medicineDemandList, "Bearer " + token)).thenReturn(pharmacistList);
		// when(service.getPharmacyCount(Mockito.anyList(),token)).thenReturn(pharmacistList);
		this.mockMvc.perform(post("/PharmacySupply").header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON)
				.content(
						"{\"medicineDemandList\":[{\"medicineName\":\"Orthoherb\",\"demandCount\":15},{\"medicineName\":\"Cholecalciferol\",\"demandCount\":2}]}")
				.accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(4)));
	}

	@Test
	void testInvalidToken() throws Exception {
		String token = "dummy";

		when(authenticateProxi.validate("Bearer " + token)).thenReturn(false);
		List<MedicineDemand> medicineDemandList = new ArrayList<MedicineDemand>();

		medicineDemandList.add(new MedicineDemand("Orthoherb", 15));
		medicineDemandList.add(new MedicineDemand("Cholecalciferol", 2));
		when(pharmacyService.getPharmacyCount(medicineDemandList, "Bearer " + token))
				.thenThrow(new InvalidTokenException("Token is invalid"));
		this.mockMvc.perform(post("/PharmacySupply").header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
				.contentType(MediaType.APPLICATION_JSON).content(
						"{\"medicineDemandList\":[{\"medicineName\":\"Orthoherb\",\"demandCount\":15},{\"medicineName\":\"Cholecalciferol\",\"demandCount\":2}]}"))
				.andExpect(status().isUnauthorized()).andExpect(jsonPath("$.message").value("Token is invalid"));
	}

}