package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

import nl.jqno.equalsverifier.EqualsVerifier;

class PharmacyMedicineSupplyTest {

	
	@Test
    void testPharmacyMedicineSupplyBean() {
        final BeanTester beanTester = new BeanTester();
        beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
        beanTester.testBean(PharmacyMedicineSupply.class);
    }
	
	@Test
	void testAllArgsConstructorforPharmacyMedicineSupply() {
		PharmacyMedicineSupply medicine = new PharmacyMedicineSupply("Phar1","Orthoherb",10);
		assertEquals("Orthoherb", medicine.getMedicineName());
	}
	 @Test
	    void testPensionerInputEqualsAndHashCode() {
	        EqualsVerifier.simple().forClass(PharmacyMedicineSupply.class).verify();
	    }
}
