package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

import nl.jqno.equalsverifier.EqualsVerifier;

class MedicineDemandListTest {

	
	@Test
    void testMedicineDemandListBean() {
        final BeanTester beanTester = new BeanTester();
        beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
        beanTester.testBean(MedicineDemandView.class);
	}    
        @Test
    	void testAllArgsConstructorforMedicineDemandList() {
    		List<MedicineDemand> l=new ArrayList<MedicineDemand>();
    		l.add(new MedicineDemand("Orthoherb",10));
    		MedicineDemandView medicine = new MedicineDemandView(l);
    		assertEquals(1, medicine.getMedicineDemandList().size());
    	}
        @Test
        void testPensionerInputEqualsAndHashCode() {
            EqualsVerifier.simple().forClass(MedicineDemandView.class).verify();
        }
    
}
