package com.pharmacy.cts.repo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest
class PharmacyRepositoryTest {
	@Autowired
	private PharmacyRepository repo;

	@Test
	void testRepo() {
		assertEquals(3, repo.getAllPharmaciesName().size());
	}

}
