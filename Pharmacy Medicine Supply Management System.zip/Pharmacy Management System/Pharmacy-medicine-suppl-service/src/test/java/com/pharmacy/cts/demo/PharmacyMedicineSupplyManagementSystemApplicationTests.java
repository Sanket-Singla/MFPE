package com.pharmacy.cts.demo;

import static org.assertj.core.api.Assertions.assertThatNoException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.pharmacy.cts.PharmacyMedicineSupplyManagementSystemApplication;

@SpringBootTest
class PharmacyMedicineSupplyManagementSystemApplicationTests {

	@Test
	void testMain() {
		PharmacyMedicineSupplyManagementSystemApplication.main(new String[] {});
		assertThatNoException();
		}


	
}