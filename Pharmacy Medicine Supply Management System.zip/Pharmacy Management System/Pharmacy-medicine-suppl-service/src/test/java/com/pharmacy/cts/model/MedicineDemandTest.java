package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

import nl.jqno.equalsverifier.EqualsVerifier;

class MedicineDemandTest {

	@Test
	void testMedicineDemandBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(MedicineDemand.class);
	}

	@Test
	void testAllArgsConstructorforMedicineDemand() {
		MedicineDemand medicine = new MedicineDemand("Orthoherb", 10);
		assertEquals("Orthoherb", medicine.getMedicineName());
	}
    @Test
    void testPensionerInputEqualsAndHashCode() {
        EqualsVerifier.simple().forClass(MedicineDemand.class).verify();
    }
}
