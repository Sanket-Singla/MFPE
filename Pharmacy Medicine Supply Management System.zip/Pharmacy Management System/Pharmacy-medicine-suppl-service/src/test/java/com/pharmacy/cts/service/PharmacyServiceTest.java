package com.pharmacy.cts.service;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pharmacy.cts.config.AuthServiceProxi;
import com.pharmacy.cts.config.MedicineStockServiceProxi;
import com.pharmacy.cts.exception.InvalidTokenException;
import com.pharmacy.cts.model.MedicineDemand;
import com.pharmacy.cts.model.MedicineStock;
import com.pharmacy.cts.model.PharmacyMedicineSupply;
import com.pharmacy.cts.repo.PharmacyRepository;

@AutoConfigureMockMvc
@SpringBootTest
class PharmacyServiceTest {

	@MockBean
	private MedicineStockServiceProxi medicineStockServiceProxi;
	@MockBean
	private PharmacyRepository pharmacyRepository;

	@Autowired
	private PharmacyService pharmacyService;

	@MockBean
	private AuthServiceProxi authenticateProxi;

	@Test
	void testService() {

		List<String> pharList = List.of("Phar1", "Phar2");

		when(pharmacyRepository.getAllPharmaciesName()).thenReturn(pharList);
		
		assertEquals(pharList, pharmacyService.getAllPharmaciesName());
	}

	@Test
	void testServiceLogictrue() throws Exception {
		String token = "dummy";
		when(authenticateProxi.validate("Bearer " + token)).thenReturn(true);

		List<MedicineStock> medicines = new ArrayList<>();
		medicines.add(new MedicineStock(1, "Orthoherb", Arrays.asList("ch1", "ch2", "ch3"), "Orthopaedics",
				LocalDate.now(), 10));
		medicines.add(new MedicineStock(2, "Cholecalciferol", Arrays.asList("ch2", "ch3"), "Gynaecology",
				LocalDate.now(), 5));

		when(medicineStockServiceProxi.getMedicineStockInfo(token)).thenReturn(medicines);

		List<String> pharList = List.of("Phar1", "Phar2");

		when(pharmacyRepository.getAllPharmaciesName()).thenReturn(pharList);

		List<MedicineDemand> medicineDemandList = new ArrayList<MedicineDemand>();

		medicineDemandList.add(new MedicineDemand("Orthoherb", 15));
		medicineDemandList.add(new MedicineDemand("Cholecalciferol", 2));

		List<PharmacyMedicineSupply> pharmacies = pharmacyService.getPharmacyCount(medicineDemandList, "Bearer " + token);

		assertEquals(4,pharmacies.size());
	}

	@Test
	void testGetAllMedicineStockWithInvalidToken() {
		List<MedicineDemand> medicineDemandList = new ArrayList<MedicineDemand>();

		medicineDemandList.add(new MedicineDemand("Orthoherb", 15));
		medicineDemandList.add(new MedicineDemand("Cholecalciferol", 2));

		String token = "dummy";
		when(authenticateProxi.validate(token)).thenReturn(false);
		assertThatExceptionOfType(InvalidTokenException.class)
				.isThrownBy(() -> pharmacyService.getPharmacyCount(medicineDemandList, token)).withMessage("Token is invalid");

	}

}
