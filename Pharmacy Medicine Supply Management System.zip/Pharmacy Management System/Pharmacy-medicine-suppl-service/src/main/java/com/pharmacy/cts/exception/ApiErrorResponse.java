package com.pharmacy.cts.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;

@Getter
public class ApiErrorResponse {

	private HttpStatus httpStatus;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timeStamp;

	private String message;

	private String localizedMessage;

	public ApiErrorResponse() {
		timeStamp = LocalDateTime.now();
	}

	public ApiErrorResponse(HttpStatus httpStatus, String message, Throwable t) {
		this();
		this.httpStatus = httpStatus;
		this.message = message;
		this.localizedMessage = t.getLocalizedMessage();
	}
}