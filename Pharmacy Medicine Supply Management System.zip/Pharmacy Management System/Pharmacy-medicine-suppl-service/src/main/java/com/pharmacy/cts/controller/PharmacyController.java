
package com.pharmacy.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.pharmacy.cts.exception.InvalidTokenException;
import com.pharmacy.cts.model.MedicineDemandView;
import com.pharmacy.cts.model.PharmacyMedicineSupply;
import com.pharmacy.cts.service.PharmacyService;

import io.swagger.annotations.Api;

@RestController
@Api("Pharmacy Supply resource REST endpoint")
public class PharmacyController {
	@Autowired
	private PharmacyService pharmacyService;

	/**
	 * Method to get the pharmacy medicine supply information based upon demand and
	 * medicine stock information
	 * 
	 * calls getPharmacyCount method from pharmacyService class
	 * 
	 * @param token              is the JWT token for securing end-points
	 * 
	 * @param medicineDemandList is the list of medicine demands from the order
	 *                           taken offline
	 * 
	 * @return This returns List<PharmacyMedicineSupply> on successful execution
	 *         else throws exception
	 * 
	 */

	@PostMapping("/PharmacySupply")
	public List<PharmacyMedicineSupply> getPharmacySupply(@RequestHeader(name = "Authorization") String token,
			@RequestBody MedicineDemandView medicineDemandList) throws InvalidTokenException {

		return pharmacyService.getPharmacyCount(medicineDemandList.getMedicineDemandList(), token);

	}

}