package com.pharmacy.cts.repo;

import java.util.List;

import org.springframework.stereotype.Repository;


@Repository
public class  PharmacyRepository {
	private List<String> pharmacyList = List.of("Walgreens Company", "Walmart","Giant Eagle Inc");
	

    public List<String> getAllPharmaciesName(){
    	return pharmacyList;
    }
}
