package com.pharmacy.cts.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

@ApiModel(description = "Model class for PharmacyMedicineSupply")
public class PharmacyMedicineSupply {



	@ApiModelProperty(value = "Name of the Pharmasists")
	private String pharName;
	@ApiModelProperty(value = "Name of the medicine")
	private String medicineName;
	@ApiModelProperty(value = "Supply Count of the medicine")
	private int supplyCount;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((medicineName == null) ? 0 : medicineName.hashCode());
		result = prime * result + ((pharName == null) ? 0 : pharName.hashCode());
		result = prime * result + supplyCount;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PharmacyMedicineSupply other = (PharmacyMedicineSupply) obj;
		if (medicineName == null) {
			if (other.medicineName != null)
				return false;
		} else if (!medicineName.equals(other.medicineName))
			return false;
		if (pharName == null) {
			if (other.pharName != null)
				return false;
		} else if (!pharName.equals(other.pharName))
			return false;
		return supplyCount == other.supplyCount;
	}
}
