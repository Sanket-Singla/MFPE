package com.pharmacy.cts.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@NoArgsConstructor
@AllArgsConstructor
@ToString

@ApiModel(description = "Model class for list of Medicine Demand")
public class MedicineDemandView {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((medicineDemandList == null) ? 0 : medicineDemandList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MedicineDemandView other = (MedicineDemandView) obj;
		if (medicineDemandList == null) {
			if (other.medicineDemandList != null)
				return false;
		} else if (!medicineDemandList.equals(other.medicineDemandList))
			return false;
		return true;
	}

	@ApiModelProperty(value = "List of the Medicine Demand")
	private List<MedicineDemand> medicineDemandList;
}
