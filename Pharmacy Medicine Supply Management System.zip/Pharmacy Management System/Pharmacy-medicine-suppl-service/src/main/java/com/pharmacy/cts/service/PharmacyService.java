package com.pharmacy.cts.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.cts.config.AuthServiceProxi;
import com.pharmacy.cts.config.MedicineStockServiceProxi;
import com.pharmacy.cts.exception.InvalidTokenException;
import com.pharmacy.cts.model.MedicineDemand;
import com.pharmacy.cts.model.MedicineStock;
import com.pharmacy.cts.model.PharmacyMedicineSupply;
import com.pharmacy.cts.repo.PharmacyRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PharmacyService {
	@Autowired
	private PharmacyRepository pharmacyRepository;
	@Autowired
	private MedicineStockServiceProxi medicineStockServiceProxi;
	@Autowired
	private AuthServiceProxi authServiceProxi;

	public List<String> getAllPharmaciesName() {
		return pharmacyRepository.getAllPharmaciesName();
	}

	public List<PharmacyMedicineSupply> getPharmacyCount(List<MedicineDemand> medicineDemandList, String token)
			throws InvalidTokenException {
		if (!authServiceProxi.validate(token)) {
			throw new InvalidTokenException("Token is invalid");
		}
		List<PharmacyMedicineSupply> pharmacies = new ArrayList<>();
		List<MedicineStock> medicineStockInfo = medicineStockServiceProxi.getMedicineStockInfo(token);
		int supplyCount = 0;
		int size = getAllPharmaciesName().size();
		/* the count should be split equally among all the pharmacists. If the stock
		 * count is lesser than the demand count, then the stock count should be
		 * considered otherwise demand count.
		 */
		for (MedicineDemand i : medicineDemandList) {
			for (MedicineStock j : medicineStockInfo) {
				if (i.getMedicineName().equalsIgnoreCase(j.getMedicineName())) {
					if (j.getNoOfTabletsInStock() < i.getDemandCount()) {
						supplyCount = j.getNoOfTabletsInStock() / size;
					} else {
						supplyCount = i.getDemandCount() / size;
					}
					break;
				}
			}
			for (String names : getAllPharmaciesName()) {
				pharmacies.add(new PharmacyMedicineSupply(names, i.getMedicineName(), supplyCount));
			}
		}
		log.debug("pharmacyList: " + pharmacies);
		return pharmacies;

	}
}
