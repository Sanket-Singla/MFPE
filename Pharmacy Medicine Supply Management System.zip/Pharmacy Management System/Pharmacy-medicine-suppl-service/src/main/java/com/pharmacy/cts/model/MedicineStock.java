package com.pharmacy.cts.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.ElementCollection;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ApiModel(description = "Model class for Medicine Stock")
public class MedicineStock {

	@ApiModelProperty(value = "Id of the medicine")
	private Integer medicineId;
	@ApiModelProperty(value = "Name of the medicine")
	private String medicineName;
	@ApiModelProperty(value = "Chemical composition of the medicine")
	@ElementCollection
	private List<String> chemicalComposition;
	@ApiModelProperty(value = "Target ailment of the medicine")
	private String targetAilment;
	@ApiModelProperty(value = "Expiry date of the medicine")
	private LocalDate dateOfExpiry;
	@ApiModelProperty(value = "Number of tablets available in stock of the medicine")
	private Integer noOfTabletsInStock;


}
