package com.cognizant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.exception.InvalidCredentialsException;
import com.cognizant.model.UserCredentials;
import com.cognizant.service.UserDetailsServiceImpl;
import com.cognizant.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class AuthController {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	/**
	 * Method to check whether login credentials are correct or not
	 * 
	 * @param userCredentials user credentials contain user name and password
	 * @return This returns token on successful login else throws exception
	 * 
	 * @throws InvalidCredentailsException Throws exception when invalid credentials
	 *                                     are provided
     * @throws UserNotFoundException Throws exception when user does
	 *                                     not exist
	 */
	@PostMapping("/login")
	public String login(@RequestBody UserCredentials userCredentials){
		log.info("{START} : login()");

		String endLog = "{END} : login()";
		try {
			UserDetails user = userDetailsService.loadUserByUsername(userCredentials.getUserName());
			if (user.getPassword().equals(userCredentials.getPassword())) {
				String token = jwtUtil.generateToken(user.getUsername());
				log.info(endLog);
				return token;
			} else {
				log.info(endLog);
				throw new InvalidCredentialsException("Invalid credentials");
			}
		} catch (AuthenticationException | NullPointerException e) {
			log.info(endLog);
			throw new UsernameNotFoundException("Invalid User name");

		}
	}
	
	
	/**
	 * Method to validate the token
	 * 
	 * @param token1 This is the token send for authentication
	 * 
	 * @return This returns true/false based on token validity
	 */
	@GetMapping("/validate")
	public ResponseEntity<Boolean> validate(@RequestHeader(name = "Authorization") String token1) {
		log.info("{START} : validate()");
		String token = token1.substring(7);

		try {
			UserDetails user = userDetailsService.loadUserByUsername(jwtUtil.extractUsername(token));
			log.info("{END} : validate()");
			return new ResponseEntity<>(jwtUtil.validateToken(token, user), HttpStatus.OK);

		} catch (Exception e) {
			log.info("{END} : validate()");
			return new ResponseEntity<>(false, HttpStatus.FORBIDDEN);
		}

	}
	
	/**
	 * Method to check the apllication's status
	 * @return This returns OK when application is up
	 */
	
	@GetMapping("/health-check")
    public ResponseEntity<String> healthCheck() {
        return new ResponseEntity<>("OK", HttpStatus.OK);
    }

	
}
