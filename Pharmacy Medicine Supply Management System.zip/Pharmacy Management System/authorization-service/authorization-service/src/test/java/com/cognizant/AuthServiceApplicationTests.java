package com.cognizant;


import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServiceApplicationTests {

	@Test
	void contextLoads() {
		AuthServiceApplication.main(new String[] {});
		Assertions.assertThatNoException();
	}

}
