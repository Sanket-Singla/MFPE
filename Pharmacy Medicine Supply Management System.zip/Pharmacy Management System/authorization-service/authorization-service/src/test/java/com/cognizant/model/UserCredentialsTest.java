package com.cognizant.model;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCredentialsTest {

	@Mock
	UserCredentials user;
	
	@BeforeEach
	public void setUp() {
		user = new UserCredentials();
		user.setUserName("saivi");
		user.setPassword("abc");
	}
	
	@Test
	void userCredentialsAllConstructorTest()
	{
		UserCredentials userCredentials = new UserCredentials("saivi", "abc");
		assertEquals("saivi", userCredentials.getUserName());
	}
	
	@Test
	void userNameTest()
	{
		assertEquals("saivi", user.getUserName());
	}
	
	@Test
	void passwordTest()
	{
		assertEquals("abc", user.getPassword());
	}
	
	@Test
	void toStringTest() {
		String string = user.toString();
		assertEquals(string, user.toString());
	}
	
	@Test
	void testEqualsMethod() {
		boolean equals = user.equals(user);
		assertTrue(equals);
	}
	
	@Test
	void testHashCodeMethod() {
		int hashCode = user.hashCode();
		assertEquals(hashCode, user.hashCode());
	}

}
