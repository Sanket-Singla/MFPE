package com.cognizant.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.web.servlet.MockMvc;

import com.cognizant.exception.UserNotFoundException;
import com.cognizant.model.MyUser;
import com.cognizant.model.UserCredentials;
import com.cognizant.repository.UserRepo;
import com.cognizant.service.UserDetailsServiceImpl;
import com.cognizant.util.JwtUtil;

@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	JwtUtil jwtutil;

	@MockBean
	UserDetailsServiceImpl userDetailsServiceImpl;

	@MockBean
	UserRepo userRepo;

	@Test
	void validLoginTest() throws Exception {

		UserCredentials user = new UserCredentials("admin", "admin");
		UserDetails value = new User(user.getUserName(), user.getPassword(), new ArrayList<>());
		
		when(userDetailsServiceImpl.loadUserByUsername("admin")).thenReturn(value);
		when(jwtutil.generateToken(user.getUserName())).thenReturn("token");
		
		this.mvc
		.perform(post("/login")
		.contentType(MediaType.APPLICATION_JSON)
		.content("{\"userName\":\"admin\",\"password\":\"admin\"}")
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$").value("token"));
		
	}
	
	@Test
	void invalidLoginTest() throws Exception {
		UserCredentials user = new UserCredentials("admin", "abc");
		UserDetails value = new User(user.getUserName(), "admin", new ArrayList<>());
		when(userDetailsServiceImpl.loadUserByUsername(user.getUserName())).thenReturn(value);
		this.mvc
		.perform(post("/login")
		.contentType(MediaType.APPLICATION_JSON)
		.content("{\"userName\":\"admin\",\"password\":\"abc\"}")
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isNotFound())
		.andExpect(jsonPath("$.message").value("Invalid credentials"));
		
	}
	

	
	@Test
	 void userNameNotFoundLoginTest() throws Exception {
		UserCredentials user = new UserCredentials("123", "abc");
		when(userDetailsServiceImpl.loadUserByUsername(user.getUserName())).thenThrow(UserNotFoundException.class);
		
		this.mvc
		.perform(post("/login")
		.contentType(MediaType.APPLICATION_JSON)
		.content("{\"userName\":\"123\",\"password\":\"abc\"}")
		.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isNotFound())
		.andExpect(jsonPath("$.message").value("Invalid User name"));

		
	}
	


	@Test
	void validateTestValidtoken() throws Exception {
		
		UserCredentials user = new UserCredentials("admin", "admin");
		UserDetails value = new User(user.getUserName(), "admin", new ArrayList<>());
		when(userDetailsServiceImpl.loadUserByUsername(user.getUserName())).thenReturn(value);
		when(jwtutil.validateToken("token", value)).thenReturn(true);
		when(jwtutil.extractUsername("token")).thenReturn("admin");
		
		MyUser user1 = new MyUser(1, "admin", "admin");
		Optional<MyUser> data = Optional.of(user1);
		
		when(userRepo.findById(1)).thenReturn(data);
		this.mvc
		.perform(get("/validate")
		.header("Authorization", "Bearer token"))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$").value("true"));

	}
	
	@Test
	void validateTestInValidUsertoken() throws Exception {

		UserCredentials user = new UserCredentials("admin", "admin");
		UserDetails value = new User(user.getUserName(), "admin", new ArrayList<>());
		when(userDetailsServiceImpl.loadUserByUsername(user.getUserName())).thenReturn(value);
		when(jwtutil.validateToken("token", value)).thenReturn(false);
		when(jwtutil.extractUsername("token")).thenReturn("admin");
		MyUser user1 = new MyUser(1, "admin", "admin");
		Optional<MyUser> data = Optional.of(user1);
		when(userRepo.findById(1)).thenReturn(data);
		this.mvc.perform(get("/validate").header("Authorization", "Bearer token")).andExpect(status().isOk())
				.andExpect(jsonPath("$").value("false"));

	}

	@Test
	void validateTestInValidtoken() throws Exception {
		
		UserCredentials user = new UserCredentials("admin", "admin");
		UserDetails value = new User(user.getUserName(), "admin", new ArrayList<>());
		when(jwtutil.extractUsername("token")).thenThrow(UserNotFoundException.class);
		when(userDetailsServiceImpl.loadUserByUsername(user.getUserName())).thenThrow(UserNotFoundException.class);
		when(jwtutil.validateToken("token", value)).thenReturn(false);
		
		this.mvc
		.perform(get("/validate")
		.header("Authorization", "Bearer token"))
		.andExpect(status().isForbidden())
		.andExpect(jsonPath("$").value("false"));

	}

}
