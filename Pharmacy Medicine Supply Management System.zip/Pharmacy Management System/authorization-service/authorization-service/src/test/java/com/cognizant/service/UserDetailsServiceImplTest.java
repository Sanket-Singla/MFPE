package com.cognizant.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.model.MyUser;
import com.cognizant.repository.UserRepo;


@SpringBootTest
class UserDetailsServiceImplTest {
	
	@Mock
	UserRepo repo;
	
	@InjectMocks
	UserDetailsServiceImpl userDetailsService;

	@Test
	 void loadUserByUsernameTest() {
		
		MyUser user = new MyUser(1,"admin","admin");
		when(repo.findByUserName("admin")).thenReturn(user);
		UserDetails loadUserByUsername = userDetailsService.loadUserByUsername("admin");
		assertEquals(user.getUserName(),loadUserByUsername.getUsername());
	}

}
