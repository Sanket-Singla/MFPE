package com.cognizant.model;




import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class MyUserTest {

	@Mock
	MyUser myUser;
	
	@BeforeEach
	public void setUp() {
		myUser = new MyUser();
		myUser.setUserId(1);
		myUser.setUserName("saivi");
		myUser.setPassword("abc");
	}
	
	@Test
	void userCredentialsAllConstructorTest()
	{
		MyUser user = new MyUser(1, "saivi", "abc");
		assertEquals("saivi", user.getUserName());
	}
	
	@Test
	void userIdTest()
	{
		assertEquals(1, myUser.getUserId());
	}
	
	@Test
	void userNameTest()
	{
		assertEquals("saivi", myUser.getUserName());
	}
	
	@Test
	void passwordTest()
	{
		assertEquals("abc", myUser.getPassword());
	}
	
	@Test
	void toStringTest() {
		String string = myUser.toString();
		assertEquals(string, myUser.toString());
	}
	
	@Test
	void testEqualsMethod() {
		boolean equals = myUser.equals(myUser);
		assertTrue(equals);
	}
	
	@Test
	void testHashCodeMethod() {
		int hashCode = myUser.hashCode();
		assertEquals(hashCode, myUser.hashCode());
	}

}
