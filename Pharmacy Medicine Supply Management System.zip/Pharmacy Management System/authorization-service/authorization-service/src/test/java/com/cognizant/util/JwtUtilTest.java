package com.cognizant.util;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

@SpringBootTest
class JwtUtilTest {

	UserDetails userDetails;
	
	@InjectMocks
	JwtUtil jwtUtil;
	
	
	
	@Test
	 void generateTokenTest() {
		userDetails = new User("admin", "admin", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userDetails.getUsername());
		assertNotNull(generateToken);
	}

	@Test
	 void validateTokenTest() {
		userDetails = new User("admin", "admin", new ArrayList<>());
		String generateToken = jwtUtil.generateToken(userDetails.getUsername());
		Boolean validateToken = jwtUtil.validateToken(generateToken, userDetails);
		assertEquals(true, validateToken);
	}


	@Test
	 void validateTokenWithInvalidCredentials() {
		userDetails = new User("dummy", "dummy", new ArrayList<>());
		String generateToken = jwtUtil.generateToken("sanket");
		Boolean validateToken = jwtUtil.validateToken(generateToken, userDetails);
		assertEquals(false, validateToken);
	}

}
