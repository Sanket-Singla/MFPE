insert into user(id, name, password) values (1, 'sanket', 'sanket@123');
insert into user(id, name, password) values (2, 'nikita', 'nikita@123');
insert into user(id, name, password) values (3, 'prashant', 'prashant@123');
insert into user(id, name, password) values (4, 'admin', 'cts@123');