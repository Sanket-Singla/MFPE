package com.cognizant.exception;

public class InvalidCredentialsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method sets the custom error message
	 * 
	 * @param message
	 */
	public InvalidCredentialsException(String message) {
		super(message);
	}

}
