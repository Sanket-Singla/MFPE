package com.pharmacy.cts.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity
@Table(name = "doctors")
@ApiModel(description = "The model class for storing the doctor's information")
public class Doctor {

	@Id
	private Integer doctorId;
	@ApiModelProperty(value = "Doctor's Name", example = "Doctor1")
	private String doctorName;
	@ApiModelProperty(value = "The type of treatment provided by the doctor", example = "Orthopaedics")
	private String treatingAilment;
	@ApiModelProperty(value = "Doctor's Contact Number", example = "9876543210")
	private long contactNumber;
}
