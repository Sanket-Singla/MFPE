package com.pharmacy.cts.controller;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.pharmacy.cts.config.AuthServiceProxi;
import com.pharmacy.cts.config.MedicineStockServiceProxi;
import com.pharmacy.cts.exception.InvalidDateException;
import com.pharmacy.cts.exception.InvalidTokenException;
import com.pharmacy.cts.model.MedicineStock;
import com.pharmacy.cts.model.RepSchedule;
import com.pharmacy.cts.service.RepScheduleService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Api("RepSchedule resource REST endpoint")
public class RepScheduleController {

	@Autowired
	private RepScheduleService repScheduleService;

	@Autowired
	private MedicineStockServiceProxi medicineStockServiceProxi;

	@Autowired
	private AuthServiceProxi authServiceProxi;

	/**
	 * Method to create and return representative's schedule based on Start Date for
	 * 5 days skipping Sundays
	 * 
	 * 
	 * This method calls validate method from authorization service to validate the
	 * JWT token
	 * 
	 * calls getMedicineStockInfo method from medicine stock service to get the
	 * current stock information from the database
	 * 
	 * 
	 * calls mapSchedule method to map the representative's schedule in the
	 * in-memory database
	 * 
	 * calls findAllByStartDate method to get the representative's schedule from the
	 * provided date
	 * 
	 * @param startDate is the start date from which the representative's schedule
	 *                  will be mapped
	 * 
	 * @param token     is the JWT token for securing end-points
	 * 
	 * @return This returns List<RepSchedule> on successful execution else throws
	 *         exception
	 * 
	 * @throws InvalidTokenException Throws exception when token is invalid or token
	 *                               is expired
	 * @throws InvalidDateException  Throws exception when startDate format is
	 *                               invalid
	 * 
	 * 
	 */
	@GetMapping("/RepSchedule")
	@ApiOperation(value = "Get Rep Schedules", notes = "Map the Medical representatives to the doctors according to the start date and return the list of RepSchedule objects")
	public List<RepSchedule> getRepSchedules(
			@ApiParam("startDate passed as request parameter") @RequestParam String startDate,
			@ApiParam("JWT Token passed as Authorization header") @RequestHeader("Authorization") String token) {
		LocalDate date = null;
		if (!authServiceProxi.validate(token)) {
			throw new InvalidTokenException("Token is invalid");
		}
		try {
			date = LocalDate.parse(startDate);
			log.debug("startDate := " + date);
		} catch (DateTimeException e) {
			throw new InvalidDateException("Invalid Date Format");
		}
		List<MedicineStock> medicineStockInfo = medicineStockServiceProxi.getMedicineStockInfo(token);

		log.debug("medicineStockInfo := " + medicineStockInfo);

		repScheduleService.mapSchedule(medicineStockInfo, date);

		List<RepSchedule> schedule = repScheduleService.findAllByStartDate(date);
		log.debug("schedule := " + schedule);
		return schedule;
	}
	
	/**
	 * Method to check the apllication's status
	 * @return This returns OK when application is up
	 */
	
	@GetMapping("/health-check")
    public ResponseEntity<String> healthCheck() {
        return new ResponseEntity<>("OK", HttpStatus.OK);
    }

}
