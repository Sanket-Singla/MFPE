package com.pharmacy.cts.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
@ToString
@Entity@Table(name = "medical_representatives")
@ApiModel(description = "The model class for storing the Medical Representative's information")
public class MedicalRep {
	
	@Id@ApiModelProperty(value = "Medical Representative's Id", example = "1001")
	private Integer repId;
	@ApiModelProperty(value = "Medical Representative's Name", example = "R1")
	private String repName;
}
