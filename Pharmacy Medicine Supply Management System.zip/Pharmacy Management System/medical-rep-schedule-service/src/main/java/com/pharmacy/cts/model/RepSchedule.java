package com.pharmacy.cts.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "rep_schedule")
@NoArgsConstructor
@Getter
@Setter
@ToString
@ApiModel(description = "The representative's schedulle model class", value = "Medical Representative Schedule")
public class RepSchedule {

	@Id
	@GeneratedValue
	@ApiModelProperty(value = "The schedule Id", example = "1")
	private Integer scheduleId;
	@ApiModelProperty(value = "The Medical Representative's Id", example = "1001")
	private Integer repId;
	@ApiModelProperty(value = "The Medical Representative's Name", example = "Representative1")
	private String repName;
	@ApiModelProperty(value = "The name of the doctor which is mapped to the representative", example = "Doctor1")
	private String doctorName;
	@ApiModelProperty(value = "The List of Medicines that concerns the doctor", example = "[Dolo-650]")
	@ElementCollection
	private List<String> medicine;
	@ApiModelProperty(value = "The Medical Representative's meeting time slot with the Doctor", example = "1 to 2 pm")
	private String meetingSlot;
	@ApiModelProperty(value = "The Scheduled date for the meeting", example = "30-Jul-2021")
	private LocalDate dateOfMeeting;
	@ApiModelProperty(value = "The contact number of the doctor which is mapped to the representative", example = "9876543210")
	private long contactNumber;

	public RepSchedule(Integer repId, String repName, String doctorName, List<String> medicine, String meetingSlot,
			LocalDate dateOfMeeting, long contactNumber) {
		super();
		this.repId = repId;
		this.repName = repName;
		this.doctorName = doctorName;
		this.medicine = medicine;
		this.meetingSlot = meetingSlot;
		this.dateOfMeeting = dateOfMeeting;
		this.contactNumber = contactNumber;
	}

}