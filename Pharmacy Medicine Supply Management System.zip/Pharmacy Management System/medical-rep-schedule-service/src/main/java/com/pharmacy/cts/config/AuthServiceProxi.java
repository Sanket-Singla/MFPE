package com.pharmacy.cts.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(name = "auth-service", url = "${auth.feign.dns}")
public interface AuthServiceProxi {

	@GetMapping("/validate")
	public boolean validate(@RequestHeader(name = "Authorization") String token);
}