package com.pharmacy.cts.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.cts.model.Doctor;
import com.pharmacy.cts.model.MedicalRep;
import com.pharmacy.cts.model.MedicineStock;
import com.pharmacy.cts.model.RepSchedule;
import com.pharmacy.cts.repo.DoctorRepo;
import com.pharmacy.cts.repo.MedicalRepRepo;
import com.pharmacy.cts.repo.RepScheduleRepo;

@Service
public class RepScheduleService {

	private static final String[] TIMESLOTS = { "1 PM to 2 PM", "2 PM to 3 PM" };
	@Autowired
	private RepScheduleRepo repo;

	@Autowired
	private DoctorRepo doctorRepo;

	@Autowired
	private MedicalRepRepo medicalRepo;

	/**
	 * This method calls the RepSchedule repository's method to find the
	 * schedule from the start date specified
	 * 
	 * @return list of objects of class RepSchedule
	 */
	public List<RepSchedule> findAllByStartDate(LocalDate startDate) {
		return repo.findByDateOfMeetingGreaterThanEqual(startDate);
	}

	/**
	 * This method calls the RepSchedule repository's method to save the
	 * schedule
	 */
	public void saveSchedule(RepSchedule schedule) {
		repo.save(schedule);
	}
	
	/**
	 * This method calls the Doctors repository's method to get the
	 * doctors information
	 * 
	 * This method calls the MedicalRepresentative repository's repository's method to get the
	 * representative's information
	 * 
	 * It starts from the startDate passed as parameter and maps each representative to the doctor one by one
	 * 
	 * This method calls saveSchedule method to save the schedule into database
	 */
	public void mapSchedule(List<MedicineStock> medicineStocks, LocalDate startDate) {
		List<Doctor> doctors = doctorRepo.findAll();
		List<MedicalRep> reps = medicalRepo.findAll();
		int i = 0;
		LocalDate date = startDate;
		for (int day = 1; day <= 5; day++) {
			Doctor doctor = doctors.get(day - 1);
			MedicalRep rep = reps.get((day - 1) % 3);
			List<String> medicines = new ArrayList<>();
			for (MedicineStock medicine : medicineStocks) {
				if (medicine.getTargetAilment().equalsIgnoreCase(doctor.getTreatingAilment())) {
					medicines.add(medicine.getMedicineName());
				}
			}
			if (date.getDayOfWeek().equals(DayOfWeek.SUNDAY)) {
				date = date.plusDays(1);
			}
			RepSchedule schedule = new RepSchedule(rep.getRepId(), rep.getRepName(), doctor.getDoctorName(), medicines,
					TIMESLOTS[i % 2], date, doctor.getContactNumber());
			saveSchedule(schedule);
			date = date.plusDays(1);
			if (day % 2 == 0) {
				i++;
			}
		}
	}

}
