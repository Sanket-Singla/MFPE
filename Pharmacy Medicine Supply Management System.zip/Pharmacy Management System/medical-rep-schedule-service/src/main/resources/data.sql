insert into doctors (doctor_id, doctor_name, treating_ailment, contact_number) values (1,'Doctor1','Orthopaedics',9884122113), (2,'Doctor2','General',9884122113),
(3,'Doctor3','General',9884122113),(4,'Doctor4','Orthopaedics',9884122113), (5,'Doctor5','Gynaecology',9884122113);


insert into medical_representatives (rep_id,rep_name) values (1001,'R1'),
(1002,'R2'),
(1003,'R3');