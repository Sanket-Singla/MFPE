package com.pharmacy.cts;

import java.io.IOException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalRepScheduleServiceApplicationTest {

	@Test
	void applicationStarts() throws IOException {
		MedicalRepScheduleServiceApplication.main(new String[] {});
		Assertions.assertThatNoException();
	}
}
