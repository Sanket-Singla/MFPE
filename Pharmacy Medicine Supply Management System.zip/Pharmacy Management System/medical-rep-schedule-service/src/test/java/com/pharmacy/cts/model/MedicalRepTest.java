package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class MedicalRepTest {
	 @Test
	    void testMedicalRepBean() {
	        final BeanTester beanTester = new BeanTester();
	        beanTester.testBean(MedicalRep.class);
	    }

	 @Test
		void testAllArgsConstructor() {
			MedicalRep rep=new MedicalRep(1, "rep1");
			assertEquals("rep1",rep.getRepName());
		}

	   
}
