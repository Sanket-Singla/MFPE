package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class DoctorTest {
	@Test
	void testDoctorBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.testBean(Doctor.class);
	}

	@Test
	void testAllArgsConstructor() {
		Doctor doc=new Doctor(1,"Dr. Nigam", "Orthopaedics", Long.parseLong("9876543210"));
		assertEquals("Dr. Nigam",doc.getDoctorName());
	}
}
