package com.pharmacy.cts.model;

import java.time.LocalDate;

import org.meanbean.lang.Factory;

class LocalDateTimeFactory implements Factory<LocalDate> {

	@Override
	public LocalDate create() {
		return LocalDate.now();
	}

}
