package com.pharmacy.cts.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class RepScheduleTest {
	@Test
    void testRepSchduleBean() {
        final BeanTester beanTester = new BeanTester();
        beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
        beanTester.testBean(RepSchedule.class);
    }
	
	@Test
	void testArgsConstructor() {
		List<String> medicines=new ArrayList<String>();
		medicines.add("Cholecalciferol");
		medicines.add("Orthoherb");
		RepSchedule schedule=new RepSchedule(1, "rep1", "Dr. Nigam",medicines, "1 to 2pm", LocalDate.now(), Long.parseLong("9876543210"));
		assertEquals(1,schedule.getRepId());
	}
}
