package com.pharmacy.cts.repo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pharmacy.cts.model.RepSchedule;

@DataJpaTest
class RepScheduleRepoTest {
	
	@Autowired
	private RepScheduleRepo repo;

	@Test
	void testSave() {
		List<String> medicines =  new ArrayList<>();
		medicines.add("med1");
		medicines.add("med2");
		RepSchedule repSchedule = new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 2), 9876541023l);
		Assertions.assertThat(repo.save(repSchedule)).isNotNull();
	}
	
	@Test
	void testFindByDateOfMeetingBetween() {
		List<String> medicines =  new ArrayList<>();
		medicines.add("med1");
		medicines.add("med2");
		repo.save(new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 1), 9876541023l));
		repo.save(new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 2), 9876541023l));
		repo.save(new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 3), 9876541023l));
		repo.save(new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 4), 9876541023l));
		repo.save(new RepSchedule(1001, "R1", "D1",medicines, "1 to 2 pm", LocalDate.of(2021, 02, 5), 9876541023l));
		Assertions.assertThat(repo.findByDateOfMeetingGreaterThanEqual(LocalDate.of(2021, 02, 1))).hasSize(5);
	}
	
}
