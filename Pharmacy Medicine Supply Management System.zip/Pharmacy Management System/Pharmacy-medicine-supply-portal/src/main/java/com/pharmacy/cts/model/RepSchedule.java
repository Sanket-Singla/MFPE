package com.pharmacy.cts.model;

import java.time.LocalDate;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class RepSchedule {

	private Integer scheduleId;
	private Integer repId;
	private String repName;
	private String doctorName;
	private List<String> medicine;
	private String meetingSlot;
	private LocalDate dateOfMeeting;
	private long contactNumber;

	public RepSchedule(Integer repId, String repName, String doctorName, List<String> medicine, String meetingSlot,
			LocalDate dateOfMeeting, long contactNumber) {
		super();
		this.repId = repId;
		this.repName = repName;
		this.doctorName = doctorName;
		this.medicine = medicine;
		this.meetingSlot = meetingSlot;
		this.dateOfMeeting = dateOfMeeting;
		this.contactNumber = contactNumber;
	}

}