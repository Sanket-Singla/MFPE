package com.pharmacy.cts.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.pharmacy.cts.model.MedicineDemandList;
import com.pharmacy.cts.model.PharmacyMedicineSupply;

@FeignClient(name = "pharmacy-medicine-supply-service", url = "${pharmacy.feign.dns}")
public interface PharmacyMedicineSupplyServiceProxi {
	@PostMapping("/PharmacySupply")
	public List<PharmacyMedicineSupply> getPharmacySupply(@RequestHeader(name="Authorization") String token,@RequestBody  MedicineDemandList medicineDemandList);
}
