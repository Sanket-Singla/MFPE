package com.pharmacy.cts.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.pharmacy.cts.config.AuthServiceProxi;
import com.pharmacy.cts.config.MedicalRepScheduleServiceProxi;
import com.pharmacy.cts.config.MedicineStockServiceProxi;
import com.pharmacy.cts.config.PharmacyMedicineSupplyServiceProxi;
import com.pharmacy.cts.model.MedicineDemandList;
import com.pharmacy.cts.model.User;

@Controller
@SessionAttributes(names = {"token"})
public class PortalController {

	private static final String HOME_PAGE = "redirect:/login";
	private static final String TOKEN_NAME = "token";
	private static final String BEARER = "Bearer ";

	@Autowired
	MedicalRepScheduleServiceProxi medicalRepScheduleServiceProxi;

	@Autowired
	MedicineStockServiceProxi medicineStockServiceProxi;

	@Autowired
	PharmacyMedicineSupplyServiceProxi pharmacyMedicineSupplyServiceProxi;
	@Autowired
	private AuthServiceProxi authServiceProxi;
	
	

	@GetMapping(value = { "/login", "/" })
	public String getLoginPage(ModelMap model) {
		model.addAttribute("user", new User());
		model.addAttribute("LogoutMessage","");
		model.addAttribute(TOKEN_NAME, "");
		return "index";
	}

	@PostMapping(value = { "/do-login" })
	public String doLogin(@Valid @ModelAttribute("user") User user, ModelMap model, BindingResult bindingResult,HttpSession session) {
		if (bindingResult.hasErrors()) {
			return HOME_PAGE;
		} else {
			String token = authServiceProxi.login(user);
			model.addAttribute(TOKEN_NAME, token);
		}
		return "login";
	}

	@GetMapping(value = { "/logout" })
	public String doLogOut(@ModelAttribute("user") User user,ModelMap model, SessionStatus status) {
		model.addAttribute(TOKEN_NAME, "");
		status.setComplete();
		model.addAttribute("user",new User());
		model.addAttribute("LogoutMessage","Logged Out Successfully");
		return "index";
	}

	@GetMapping("/schedule_form")
	public String scheduleForm(@ModelAttribute("user") User user,ModelMap model) {
		String token = model.getAttribute(TOKEN_NAME).toString();
		if(validate(token)) {
			return "schedule_form";
		}
		else {
			return HOME_PAGE;
		}
		
	}

	@PostMapping(value = { "/get-schedule" })
	public String getSchedule(@ModelAttribute("user") User user,String date, ModelMap model) {
		String token =model.getAttribute(TOKEN_NAME).toString();
		if(!validate(token)) {
			return HOME_PAGE;
		}
		model.addAttribute("schedule", medicalRepScheduleServiceProxi.getRepSchedules(date, BEARER+token));
		return "view_schedule";
	}

	@GetMapping("/demand_count")
	public String demandCount(@ModelAttribute("user") User user,ModelMap model) {
		String token = model.getAttribute(TOKEN_NAME).toString();
		if(!validate(token)) {
			return HOME_PAGE;
		}
		model.addAttribute("medicineStock", medicineStockServiceProxi.getMedicineStockInfo(BEARER+token));
		model.addAttribute("medicineDemandList", new MedicineDemandList());
		return "demand_count";
	}

	@PostMapping(value = { "/order-summary" })
	public ModelAndView getOrderSummary(@ModelAttribute("user") User user,MedicineDemandList medicineDemandList, ModelMap model) {
		ModelAndView view = new ModelAndView();
		String token = model.getAttribute(TOKEN_NAME).toString();
		if(!validate(token)) {
			view.setViewName(HOME_PAGE);
			return view;
		}
		view.addObject("PharmacyList", pharmacyMedicineSupplyServiceProxi.getPharmacySupply(BEARER+token, medicineDemandList));
		view.setViewName("order_summary");
		return view;
	}
	
	public boolean validate(String token) {
		if(token==null||token.length()<=7) {
			return false;
		}
		try {
			return authServiceProxi.validate(BEARER+token);
		}
		catch(Exception e) {
			return false;
		}
	}

}
