package com.pharmacy.cts.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.pharmacy.cts.model.MedicineStock;

@FeignClient(name = "medicine-stock-service", url = "${stock.feign.dns}")
public interface MedicineStockServiceProxi {
	@GetMapping("/MedicineStockInformation")
	public List<MedicineStock> getMedicineStockInfo(@RequestHeader("Authorization") String token);
}
