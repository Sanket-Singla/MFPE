package com.cts.pharmacy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacyMedicineSupplyPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
