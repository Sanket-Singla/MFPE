insert into doctors (doctor_id, doctor_name, treating_ailment, contact_number) values (1,'Neil Tyson','Orthopaedics',9884122113), (2,'Steve Johnson','General',9884122113),
(3,'Mark Johnson','General',9884122113),(4,'John Markson','Orthopaedics',9884122113), (5,'Andrew Watson','Gynaecology',9884122113);

insert into medical_representatives (rep_id,rep_name) values (1001,'John Stones'),
(1002,'Phill Jones'),
(1003,'Shaun Smith');