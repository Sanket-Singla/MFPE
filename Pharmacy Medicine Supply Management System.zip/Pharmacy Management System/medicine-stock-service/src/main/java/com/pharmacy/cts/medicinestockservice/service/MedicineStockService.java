package com.pharmacy.cts.medicinestockservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.cts.medicinestockservice.model.MedicineStock;
import com.pharmacy.cts.medicinestockservice.repo.MedicineStockRepo;

@Service
public class MedicineStockService {

	@Autowired
	private MedicineStockRepo medicineRepo;

	/*
	 * This method calls the medicine repository's method to get the medicine stock
	 * information from the database.
	 * 
	 */
	public List<MedicineStock> getAllMedicineStock() {
		return medicineRepo.findAll();
	}

}
