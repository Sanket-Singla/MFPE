package com.pharmacy.cts.medicinestockservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pharmacy.cts.medicinestockservice.model.MedicineStock;

public interface MedicineStockRepo extends JpaRepository<MedicineStock, Integer> {

}
