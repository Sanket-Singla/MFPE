package com.pharmacy.cts.medicinestockservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.pharmacy.cts.medicinestockservice.config.AuthServiceProxi;
import com.pharmacy.cts.medicinestockservice.exception.InvalidTokenException;
import com.pharmacy.cts.medicinestockservice.exception.MedicineStockEmptyException;
import com.pharmacy.cts.medicinestockservice.model.MedicineStock;
import com.pharmacy.cts.medicinestockservice.service.MedicineStockService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@Api("MedicineStock resource REST endpoint")
public class MedicineStockController {

	@Autowired
	private MedicineStockService medicineService;
	@Autowired
	private AuthServiceProxi authServiceProxi;

	/**
	 * Method to get the medicine stock information from the in-memory database
	 * 
	 * 
	 * This method calls validate method from authorization service to validate the
	 * JWT token
	 * 
	 * calls getAllMedicineStock method from medicineService class
	 * 
	 * @param token is the JWT token for securing end-points
	 * 
	 * @return This returns List<MedicineStock> on successful execution else throws
	 *         exception
	 * 
	 * @throws InvalidTokenException       Throws exception when token is invalid or
	 *                                     token is expired
	 * @throws MedicineStockEmptyException Throws exception when medicine stock is
	 *                                     empty
	 * 
	 * 
	 */

	@GetMapping("/MedicineStockInformation")
	@ApiOperation(value = "get Medicine Stock info", notes = "Returns the medicine stock information for all the medicines")
	public List<MedicineStock> getMedicineStockInfo(@RequestHeader(name = "Authorization") String token) {
		if (!authServiceProxi.validate(token)) {
			throw new InvalidTokenException("Token is invalid");
		}
		List<MedicineStock> meds = medicineService.getAllMedicineStock();
		if (meds.isEmpty()) {
			throw new MedicineStockEmptyException("Medicine stock cannot be empty");
		}
		log.debug("Medicine Stock Information"+meds);
		return meds;
	}
	
	/**
	 * Method to check the apllication's status
	 * @return This returns OK when application is up
	 */
	
	@GetMapping("/health-check")
    public ResponseEntity<String> healthCheck() {
        return new ResponseEntity<>("OK", HttpStatus.OK);
    }

}