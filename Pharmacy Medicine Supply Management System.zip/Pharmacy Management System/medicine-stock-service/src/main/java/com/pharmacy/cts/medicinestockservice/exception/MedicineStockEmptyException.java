package com.pharmacy.cts.medicinestockservice.exception;

public class MedicineStockEmptyException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MedicineStockEmptyException(String message) {
		super(message);
	}

	
}
