package com.pharmacy.cts.medicinestockservice.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.meanbean.test.BeanTester;

class MedicineStockTest {
	@Test
	void testMedicineStockBean() {
		final BeanTester beanTester = new BeanTester();
		beanTester.getFactoryCollection().addFactory(LocalDate.class, new LocalDateTimeFactory());
		beanTester.testBean(MedicineStock.class);
	}

	@Test
	void testAllArgsConstructor() {
		MedicineStock medicine = new MedicineStock(1, "Orthoherb", Arrays.asList("ch1", "ch2", "ch3"), "Orthopaedics",
				LocalDate.now(), 10);
		assertEquals("Orthoherb", medicine.getMedicineName());
	}

}
