package com.pharmacy.cts.medicinestockservice.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.pharmacy.cts.medicinestockservice.config.AuthServiceProxi;
import com.pharmacy.cts.medicinestockservice.exception.InvalidTokenException;
import com.pharmacy.cts.medicinestockservice.model.MedicineStock;
import com.pharmacy.cts.medicinestockservice.repo.MedicineStockRepo;

@SpringBootTest
class MedicineStockServiceTest {

	@Autowired
	private MedicineStockService service;
	@MockBean
	private MedicineStockRepo repo;
	@MockBean
	private AuthServiceProxi authServiceProxi;

	@Test
	void testGetAllMedicineStock() throws InvalidTokenException {
		String token = "dummy";
		List<MedicineStock> list = List.of(
				new MedicineStock(1, "med1", Arrays.asList("ch1", "ch2", "ch3"), "ailment1", LocalDate.now(), 10),
				new MedicineStock(1, "med2", Arrays.asList("ch1", "ch2"), "ailment2", LocalDate.now(), 5));
		when(authServiceProxi.validate(token)).thenReturn(true);
		when(repo.findAll()).thenReturn(list);
		List<MedicineStock> medicines = service.getAllMedicineStock();
		assertEquals(2, medicines.size());
		verify(repo, times(1)).findAll();
	}



}
