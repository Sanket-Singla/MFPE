package com.pharmacy.cts.medicinestockservice;

import static org.assertj.core.api.Assertions.assertThatNoException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineStockServiceApplicationTests {

	@Test
    void contextLoads() {
        MedicineStockServiceApplication.main(new String[] {});
        assertThatNoException();
    }

}
