package com.pharmacy.cts.medicinestockservice.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.pharmacy.cts.medicinestockservice.config.AuthServiceProxi;
import com.pharmacy.cts.medicinestockservice.exception.InvalidTokenException;
import com.pharmacy.cts.medicinestockservice.model.MedicineStock;
import com.pharmacy.cts.medicinestockservice.service.MedicineStockService;

@SpringBootTest
@AutoConfigureMockMvc
class MedicineStockControllerTest {

	@Autowired
	private MedicineStockController resource;

	@MockBean
	private MedicineStockService service;

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private AuthServiceProxi authServiceProxi;
	@Test
	void testGetMedicineStockInfo() throws Exception {
		String token="dummy";
		List<MedicineStock> list = List.of(
				new MedicineStock(1, "med1", Arrays.asList("ch1", "ch2", "ch3"), "ailment1", LocalDate.now(), 10),
				new MedicineStock(1, "med2", Arrays.asList("ch1", "ch2"), "ailment2", LocalDate.now(), 5));
		when(authServiceProxi.validate("Bearer "+token)).thenReturn(true);
		when(service.getAllMedicineStock()).thenReturn(list);
		this.mockMvc.perform(get("/MedicineStockInformation").header("Authorization", "Bearer "+token)).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON)).andExpect(jsonPath("$", hasSize(2)));

	}


	@Test
	void testGetEmptyMedicineStock() throws Exception {
		String token="dummy";
		List<MedicineStock> list = new ArrayList<>();
		when(authServiceProxi.validate("Bearer "+token)).thenReturn(true);
		when(service.getAllMedicineStock()).thenReturn(list);
		this.mockMvc.perform(get("/MedicineStockInformation").header(HttpHeaders.AUTHORIZATION, "Bearer "+token)).andExpect(status().isNotFound()).andExpect(jsonPath("$.message").value("Medicine stock cannot be empty"));
	}
	


	@Test
	void testInvalidToken() throws Exception {
		String token="dummy";
		when(authServiceProxi.validate("Bearer "+token)).thenReturn(false);
		when(service.getAllMedicineStock()).thenThrow(new InvalidTokenException("Token is invalid"));
		this.mockMvc.perform(get("/MedicineStockInformation").header(HttpHeaders.AUTHORIZATION, "Bearer "+token)).andExpect(status().isUnauthorized())
		.andExpect(jsonPath("$.message").value("Token is invalid"));
	}
	
	@Test
	void contextLoad() {
		assertThat(resource).isNotNull();
	}
}
