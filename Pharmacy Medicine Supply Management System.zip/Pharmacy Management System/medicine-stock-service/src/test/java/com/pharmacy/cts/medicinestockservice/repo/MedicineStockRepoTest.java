package com.pharmacy.cts.medicinestockservice.repo;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pharmacy.cts.medicinestockservice.model.MedicineStock;

@DataJpaTest
class MedicineStockRepoTest {

	@Autowired
	private MedicineStockRepo medicineStockRepo;

	@Test
	void testFindAllMedicines() {
		List<MedicineStock> medicines = medicineStockRepo.findAll();

		assertThat(medicines).hasSize(6);
	}

	@Test
	void testRepositoryIsNotEmpty() {
		List<MedicineStock> medicines = medicineStockRepo.findAll();
		assertThat(medicines).isNotEmpty();
	}

}
